phaser-typescript-starter
=========================

Phaser starter the way I like it.

```
npm install -g webpack webpack-dev-server
npm install
webpack-dev-server
```

open `http://localhost:8080/index.html`